import { AuthenticatedRepository } from "@/repositories/base/authenticated.repository"
import {
  dbRowToInvoice,
  dbRowToScheduledCashEvent,
  dbRowToTransaction,
} from "@/repositories/base/row-mappers"

export class CashflowRepository extends AuthenticatedRepository {
  async getInvoices() {
    const [supabase, userId] = await this.getClientAndUserId()
    const { data, error } = await supabase
      .from("invoices")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })
    if (error) throw new Error(error.message)
    return (data ?? []).map(dbRowToInvoice)
  }

  async getTransactions() {
    const [supabase, userId] = await this.getClientAndUserId()
    const { data, error } = await supabase
      .from("transactions")
      .select("*, categories(name)")
      .eq("user_id", userId)
      .order("date", { ascending: false })
    if (error) throw new Error(error.message)
    return (data ?? []).map(dbRowToTransaction)
  }

  async getScheduledCashEvents() {
    const [supabase, userId] = await this.getClientAndUserId()
    const { data, error } = await supabase
      .from("forecast_events")
      .select("*")
      .eq("user_id", userId)
      .eq("is_active", true)
      .order("event_date", { ascending: true })
    if (error) throw new Error(error.message)
    return (data ?? []).map(dbRowToScheduledCashEvent)
  }
}
