import type { Client, Invoice } from "@/lib/data"
import { AuthenticatedRepository } from "@/repositories/base/authenticated.repository"
import { dbRowToInvoice } from "@/repositories/base/row-mappers"

function dbRowsToClients(rows: any[]): Client[] {
  const seen = new Set<string>()
  const clients: Client[] = []

  for (const row of rows) {
    const name: string = row.counterparty
    if (!name || seen.has(name)) continue
    seen.add(name)
    clients.push({
      id: name,
      name,
      industry: "General",
      riskScore: "medium",
      avgPaymentDays: 30,
      paymentTerms: "Net 30",
    })
  }

  return clients
}

export class InvoicesRepository extends AuthenticatedRepository {
  async getInvoices() {
    const [supabase, userId] = await this.getClientAndUserId()
    const { data, error } = await supabase
      .from("invoices")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })
    if (error) throw new Error(error.message)
    return (data ?? []).map(dbRowToInvoice)
  }

  async getInvoiceById(invoiceId: string) {
    const [supabase, userId] = await this.getClientAndUserId()
    const { data, error } = await supabase
      .from("invoices")
      .select("*")
      .eq("id", invoiceId)
      .eq("user_id", userId)
      .single()
    if (error) return null
    return dbRowToInvoice(data)
  }

  async getClients() {
    const [supabase, userId] = await this.getClientAndUserId()
    const { data, error } = await supabase
      .from("invoices")
      .select("counterparty")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })
    if (error) throw new Error(error.message)
    return dbRowsToClients(data ?? [])
  }

  async createInvoice(invoice: Invoice) {
    const [supabase, userId] = await this.getClientAndUserId()
    const { data, error } = await supabase
      .from("invoices")
      .insert({
        user_id: userId,
        counterparty: invoice.client,
        total_amount: invoice.totalAmount ?? invoice.amount,
        paid_amount: invoice.paidAmount ?? 0,
        issue_date: invoice.issueDate,
        due_date: invoice.dueDate,
        status: invoice.status,
        description: invoice.description,
        priority: invoice.priority,
        notes: invoice.notes ?? null,
        source_data: (invoice.sourceData ?? null) as any,
        type: invoice.type ?? "receivable",
      })
      .select("*")
      .single()
    if (error) throw new Error(error.message)
    return dbRowToInvoice(data)
  }

  async updateInvoice(invoiceId: string, updates: Partial<Invoice>) {
    const [supabase, userId] = await this.getClientAndUserId()
    const dbUpdates: Record<string, unknown> = {}
    if (updates.client !== undefined) dbUpdates.counterparty = updates.client
    if (updates.amount !== undefined) dbUpdates.total_amount = updates.amount
    if (updates.totalAmount !== undefined) dbUpdates.total_amount = updates.totalAmount
    if (updates.paidAmount !== undefined) dbUpdates.paid_amount = updates.paidAmount
    if (updates.issueDate !== undefined) dbUpdates.issue_date = updates.issueDate
    if (updates.dueDate !== undefined) dbUpdates.due_date = updates.dueDate
    if (updates.status !== undefined) dbUpdates.status = updates.status
    if (updates.type !== undefined) dbUpdates.type = updates.type
    if (updates.description !== undefined) dbUpdates.description = updates.description
    if (updates.priority !== undefined) dbUpdates.priority = updates.priority
    if (updates.notes !== undefined) dbUpdates.notes = updates.notes
    if (updates.sourceData !== undefined) dbUpdates.source_data = updates.sourceData as any
    const { data, error } = await supabase
      .from("invoices")
      .update(dbUpdates)
      .eq("id", invoiceId)
      .eq("user_id", userId)
      .select("*")
      .single()
    if (error) throw new Error(error.message)
    return dbRowToInvoice(data)
  }

  async deleteInvoice(invoiceId: string) {
    const [supabase, userId] = await this.getClientAndUserId()
    const { error } = await supabase
      .from("invoices")
      .delete()
      .eq("id", invoiceId)
      .eq("user_id", userId)
    if (error) throw new Error(error.message)
  }
}
