import type { Client } from "@/lib/data"
import { AuthenticatedRepository } from "@/repositories/base/authenticated.repository"
import { dbRowToInvoice } from "@/repositories/base/row-mappers"

function buildClientsFromCounterparties(names: string[]): Client[] {
  const seen = new Set<string>()
  const clients: Client[] = []

  for (const name of names) {
    if (!name || seen.has(name)) continue
    seen.add(name)
    clients.push({
      id: name,
      name,
      industry: "General",
      riskScore: "medium",
      avgPaymentDays: 30,
      paymentTerms: "Net 30",
    })
  }

  return clients
}

export class ClientsRepository extends AuthenticatedRepository {
  async getClients() {
    const [supabase, userId] = await this.getClientAndUserId()

    const [invoicesResult, transactionsResult] = await Promise.all([
      supabase.from("invoices").select("counterparty").eq("user_id", userId),
      supabase.from("transactions").select("counterparty").eq("user_id", userId),
    ])

    if (invoicesResult.error) throw new Error(invoicesResult.error.message)
    if (transactionsResult.error) throw new Error(transactionsResult.error.message)

    const names = [
      ...(invoicesResult.data ?? []).map((r) => r.counterparty).filter(Boolean),
      ...(transactionsResult.data ?? []).map((r) => r.counterparty).filter(Boolean),
    ] as string[]

    return buildClientsFromCounterparties(names)
  }

  async getInvoices() {
    const [supabase, userId] = await this.getClientAndUserId()
    const { data, error } = await supabase
      .from("invoices")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })
    if (error) throw new Error(error.message)
    return (data ?? []).map(dbRowToInvoice)
  }
}
