import { createSupabaseServerClient } from "@/lib/supabase/server"
import { SessionNotFoundException } from "@/exceptions/auth/auth-exceptions"

export abstract class AuthenticatedRepository {
  protected async getClientAndUserId() {
    const supabase = await createSupabaseServerClient()
    const { data, error } = await supabase.auth.getUser()
    if (error || !data.user) throw new SessionNotFoundException()
    return [supabase, data.user.id] as const
  }

  protected async getUserId(): Promise<string> {
    const [, userId] = await this.getClientAndUserId()
    return userId
  }

  protected async getClient() {
    return createSupabaseServerClient()
  }
}
