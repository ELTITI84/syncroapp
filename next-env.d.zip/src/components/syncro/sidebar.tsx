"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import {
  Bell,
  ChevronRight,
  LayoutDashboard,
  Lightbulb,
  RefreshCw,
  Search,
  TrendingUp,
  Users,
  FileText,
  ArrowLeftRight,
} from "lucide-react"
import { useSWRConfig } from "swr"

import { useDashboard } from "@/hooks/use-dashboard"
import { useSession } from "@/hooks/use-session"
import { apiFetch } from "@/lib/api"
import { cn } from "@/lib/utils"
import { GlobalSearch } from "./global-search"
import { Badge } from "@/components/ui/badge"
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet"

const navItems = [
  { href: "/", label: "Inicio", icon: LayoutDashboard },
  { href: "/cashflow", label: "Flujo de caja", icon: TrendingUp },
  { href: "/invoices", label: "Facturas", icon: FileText },
  { href: "/movements", label: "Movimientos", icon: ArrowLeftRight },
  { href: "/insights", label: "Análisis", icon: Lightbulb },
  { href: "/clients", label: "Clientes", icon: Users },
]

export function Sidebar() {
  const pathname = usePathname()
  const router = useRouter()
  const { mutate } = useSWRConfig()
  const { notifications } = useDashboard()
  const { user } = useSession()
  const [lastSync, setLastSync] = useState(new Date())
  const [syncing, setSyncing] = useState(false)
  const [searchOpen, setSearchOpen] = useState(false)
  const [notificationsOpen, setNotificationsOpen] = useState(false)

  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault()
        setSearchOpen(true)
      }
    }

    document.addEventListener("keydown", handler)
    return () => document.removeEventListener("keydown", handler)
  }, [])

  const handleSync = async () => {
    setSyncing(true)
    await mutate(() => true, undefined, { revalidate: true })
    setLastSync(new Date())
    setSyncing(false)
  }

  const syncAgo = Math.round((Date.now() - lastSync.getTime()) / 60000)

  return (
    <>
      <aside className="fixed left-0 top-0 z-40 flex h-screen w-56 flex-col border-r border-sidebar-border bg-sidebar">
        <div className="flex h-14 items-center gap-2.5 border-b border-sidebar-border px-5">
          <div className="flex size-7 shrink-0 items-center justify-center overflow-hidden ">
            <img src="/logo.svg" alt="" className=" object-cover" aria-hidden />
          </div>
          <span className="text-base font-semibold tracking-tight text-foreground">SYNCRO</span>
          <Badge className="ml-auto bg-primary/10 text-primary hover:bg-primary/10">beta</Badge>
        </div>

        <button
          onClick={() => setSearchOpen(true)}
          className="mx-3 mt-3 flex items-center gap-2 rounded-md border border-border bg-muted/50 px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-muted"
        >
          <Search className="size-3.5" />
          <span>Buscar...</span>
          <kbd className="ml-auto rounded border border-border bg-muted px-1.5 py-0.5 text-[10px]">Ctrl K</kbd>
        </button>

        <nav className="flex-1 space-y-0.5 overflow-y-auto px-3 py-4">
          <p className="px-3 pb-2 text-[10px] font-medium uppercase tracking-widest text-muted-foreground">Navegación</p>
          {navItems.map(({ href, label, icon: Icon }) => {
            const active = pathname === href || (href !== "/" && pathname.startsWith(href))
            return (
              <Link
                key={href}
                href={href}
                className={cn(
                  "group flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-all",
                  active ? "border border-primary/20 bg-primary/10 font-medium text-primary" : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-foreground",
                )}
              >
                <Icon className={cn("size-4 shrink-0", active ? "text-primary" : "text-muted-foreground group-hover:text-foreground")} />
                {label}
                {active && <ChevronRight className="ml-auto size-3 text-primary" />}
              </Link>
            )
          })}
        </nav>

        <div className="space-y-2 border-t border-sidebar-border px-3 py-4">
          <button
            onClick={handleSync}
            className="flex w-full items-center gap-2 rounded-md px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-sidebar-accent hover:text-foreground"
          >
            <RefreshCw className={cn("size-4", syncing && "animate-spin")} />
            <span>{syncing ? "Sincronizando..." : "Sincronizar"}</span>
            <span className="ml-auto text-[10px]">{syncAgo === 0 ? "ahora mismo" : `hace ${syncAgo}m`}</span>
          </button>

          <button
            onClick={() => setNotificationsOpen(true)}
            className="flex w-full items-center gap-2 rounded-md px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-sidebar-accent hover:text-foreground"
          >
            <Bell className="size-4" />
            <span>Notificaciones</span>
            <span className="ml-auto flex size-4 items-center justify-center rounded-full bg-danger text-[10px] font-bold text-danger-foreground">
              {notifications.length}
            </span>
          </button>

          <div className="flex items-center gap-2.5 px-3 py-2">
            <div className="flex size-7 items-center justify-center rounded-full border border-primary/30 bg-primary/20 text-xs font-semibold text-primary">
              {user ? (user.full_name ?? user.email).slice(0, 2).toUpperCase() : ".."}
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-xs font-medium text-foreground">
                {user?.full_name ?? user?.email ?? "—"}
              </p>
              <button
                onClick={async () => {
                  await apiFetch("/api/auth/logout", { method: "POST" })
                  router.push("/login")
                }}
                className="truncate text-[10px] text-muted-foreground hover:text-foreground transition-colors"
              >
                Cerrar sesión
              </button>
            </div>
          </div>
        </div>
      </aside>

      <GlobalSearch open={searchOpen} onClose={() => setSearchOpen(false)} />

      <Sheet open={notificationsOpen} onOpenChange={setNotificationsOpen}>
        <SheetContent className="w-full sm:max-w-md">
          <SheetHeader>
            <SheetTitle>Notificaciones</SheetTitle>
            <SheetDescription>Últimas alertas que requieren tu atención.</SheetDescription>
          </SheetHeader>
          <div className="space-y-3 px-4 pb-4">
            {notifications.map((notification) => (
              <button
                key={notification.id}
                onClick={() => {
                  const query = new URLSearchParams(notification.target.params ?? {}).toString()
                  router.push(`${notification.target.pathname}${query ? `?${query}` : ""}`)
                  setNotificationsOpen(false)
                }}
                className="w-full rounded-xl border border-border/80 bg-muted/10 p-4 text-left transition-all hover:border-primary/40 hover:bg-muted/20"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <Badge className={cn(notification.severity === "critical" ? "bg-danger/15 text-danger hover:bg-danger/15" : notification.severity === "high" ? "bg-warning/15 text-warning hover:bg-warning/15" : "bg-primary/15 text-primary hover:bg-primary/15")}>
                      {notification.severity}
                    </Badge>
                    <p className="mt-3 text-sm font-semibold text-foreground">{notification.title}</p>
                    <p className="mt-1 text-sm text-muted-foreground">{notification.body}</p>
                  </div>
                  <ChevronRight className="mt-1 size-4 text-muted-foreground" />
                </div>
              </button>
            ))}
          </div>
        </SheetContent>
      </Sheet>
    </>
  )
}
