"use client"

import { useEffect, useMemo, useState } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import {
  AlertTriangle,
  ArrowUpRight,
  CheckCircle2,
  ChevronRight,
  Clock3,
  Download,
  FilePlus2,
  Filter,
  Mail,
  Search,
  User,
} from "lucide-react"
import { toast } from "sonner"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Textarea } from "@/components/ui/textarea"
import { Separator } from "@/components/ui/separator"
import { clients } from "@/lib/data"
import { useStore } from "@/lib/store"
import {
  buildHref,
  formatCurrency,
  formatSignedCurrency,
  formatShortDate,
  getBurnRate,
  getClientRecords,
  getInvoiceBucket,
  getInvoiceSummary,
  matchesInvoiceFilter,
  type InvoiceFilter,
} from "@/lib/syncro"
import { cn } from "@/lib/utils"

type QuickFilter = "all" | "overdue" | "due-soon" | "paid"

function toneForBucket(bucket: InvoiceFilter) {
  if (bucket === "overdue") return "bg-danger/15 text-danger hover:bg-danger/15"
  if (bucket === "due-soon") return "bg-warning/15 text-warning hover:bg-warning/15"
  if (bucket === "paid") return "bg-success/15 text-success hover:bg-success/15"
  return "bg-primary/15 text-primary hover:bg-primary/15"
}

function getRowBorderClass(bucket: InvoiceFilter) {
  if (bucket === "overdue") return "border-l-2 border-danger"
  if (bucket === "due-soon") return "border-l-2 border-warning"
  return ""
}

function getActionButton(bucket: InvoiceFilter, isPaid: boolean) {
  if (isPaid) return { label: "Ver detalle", variant: "ghost" as const }
  if (bucket === "overdue") return { label: "Cobrar", variant: "default" as const }
  if (bucket === "due-soon") return { label: "Recordatorio", variant: "outline" as const }
  return { label: "Abrir", variant: "ghost" as const }
}

export function InvoicesContent() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const invoices = useStore((state) => state.invoices)
  const transactions = useStore((state) => state.transactions)
  const addInvoice = useStore((state) => state.addInvoice)
  const markInvoicePaid = useStore((state) => state.markInvoicePaid)

  const [quickFilter, setQuickFilter] = useState<QuickFilter>("all")
  const [clientFilter, setClientFilter] = useState("all")
  const [search, setSearch] = useState("")
  const [selectedInvoiceId, setSelectedInvoiceId] = useState<string | null>(null)
  const [createOpen, setCreateOpen] = useState(false)
  const [form, setForm] = useState({
    clientId: clients[0]?.id ?? "",
    amount: "",
    issueDate: new Date().toISOString().slice(0, 10),
    dueDate: "",
    description: "",
    owner: "Revenue Ops",
    priority: "medium" as "high" | "medium" | "low",
  })

  useEffect(() => {
    const nextStatus = searchParams.get("status") as QuickFilter | null
    const nextClient = searchParams.get("client") ?? "all"
    const highlight = searchParams.get("highlight")

    if (nextStatus && ["all", "overdue", "due-soon", "paid"].includes(nextStatus)) {
      setQuickFilter(nextStatus)
    }
    setClientFilter(nextClient)

    if (highlight && invoices.some((invoice) => invoice.id === highlight)) {
      setSelectedInvoiceId(highlight)
    }
  }, [searchParams, invoices])

  const clientRecords = useMemo(() => getClientRecords(invoices), [invoices])
  const invoiceSummary = useMemo(() => getInvoiceSummary(invoices), [invoices])
  const burnRate = useMemo(() => getBurnRate(transactions), [transactions])
  const selectedInvoice = useMemo(
    () => invoices.find((invoice) => invoice.id === selectedInvoiceId) ?? null,
    [invoices, selectedInvoiceId],
  )

  // Count for quick filter chips
  const filterCounts = useMemo(() => {
    const all = invoices.length
    const overdue = invoices.filter((inv) => getInvoiceBucket(inv) === "overdue").length
    const dueSoon = invoices.filter((inv) => getInvoiceBucket(inv) === "due-soon").length
    const paid = invoices.filter((inv) => inv.status === "paid").length
    return { all, overdue, dueSoon, paid }
  }, [invoices])

  // Get overdue clients for collection alert
  const overdueClients = useMemo(() => {
    const overdueInvoices = invoices.filter((inv) => getInvoiceBucket(inv) === "overdue")
    const clientNames = [...new Set(overdueInvoices.map((inv) => inv.client))]
    return clientNames
  }, [invoices])

  const filteredInvoices = useMemo(() => {
    return invoices.filter((invoice) => {
      // Map quickFilter to InvoiceFilter
      let statusFilter: InvoiceFilter = "all"
      if (quickFilter === "overdue") statusFilter = "overdue"
      else if (quickFilter === "due-soon") statusFilter = "due-soon"
      else if (quickFilter === "paid") statusFilter = "paid"

      const matchesStatus = matchesInvoiceFilter(invoice, statusFilter)
      const matchesClient = clientFilter === "all" || invoice.clientId === clientFilter
      const query = search.trim().toLowerCase()
      const matchesQuery =
        !query ||
        invoice.id.toLowerCase().includes(query) ||
        invoice.client.toLowerCase().includes(query) ||
        invoice.description.toLowerCase().includes(query)

      return matchesStatus && matchesClient && matchesQuery
    })
  }, [clientFilter, invoices, search, quickFilter])

  const focusCollections = searchParams.get("focus") === "collections"

  const summaryCards = [
    {
      label: "Pendiente",
      value: formatCurrency(invoiceSummary.outstandingAmount),
      detail: `${invoices.filter((invoice) => invoice.status !== "paid").length} facturas abiertas`,
      icon: ArrowUpRight,
      tone: "text-foreground",
      href: "/invoices?status=all",
    },
    {
      label: "Vencidas",
      value: formatCurrency(invoiceSummary.overdueAmount),
      detail: `${invoiceSummary.overdueCount} facturas para cobrar`,
      icon: AlertTriangle,
      tone: "text-danger",
      href: "/invoices?status=overdue&focus=collections",
    },
    {
      label: "Por vencer",
      value: formatCurrency(invoiceSummary.dueSoonAmount),
      detail: `${invoiceSummary.dueSoonCount} facturas en 7 dias`,
      icon: Clock3,
      tone: "text-warning",
      href: "/invoices?status=due-soon",
    },
    {
      label: "Cobradas",
      value: formatCurrency(invoiceSummary.paidAmount),
      detail: "Facturas ya cerradas",
      icon: CheckCircle2,
      tone: "text-success",
      href: "/invoices?status=paid",
    },
  ]

  const exportCSV = () => {
    const rows = [
      ["ID", "Cliente", "Monto", "Fecha emision", "Vencimiento", "Estado", "Prioridad", "Responsable"].join(","),
      ...filteredInvoices.map((invoice) =>
        [
          invoice.id,
          invoice.client,
          invoice.amount,
          invoice.issueDate,
          invoice.dueDate,
          invoice.status,
          invoice.priority,
          invoice.owner,
        ].join(","),
      ),
    ]

    const blob = new Blob([rows.join("\n")], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const anchor = document.createElement("a")
    anchor.href = url
    anchor.download = "syncro-facturas.csv"
    anchor.click()
    URL.revokeObjectURL(url)
    toast.success("Facturas exportadas")
  }

  const handleCreateInvoice = () => {
    const client = clients.find((item) => item.id === form.clientId)
    if (!client) return

    const id = `FAC-${String(Date.now()).slice(-3)}`

    addInvoice({
      id,
      client: client.name,
      clientId: client.id,
      amount: Number(form.amount),
      issueDate: form.issueDate,
      dueDate: form.dueDate,
      status: "pending",
      description: form.description,
      owner: form.owner,
      priority: form.priority,
      paymentHistory: [],
      expectedPayments: form.dueDate
        ? [
            {
              date: form.dueDate,
              amount: Number(form.amount),
              note: "Pago esperado en la fecha de vencimiento.",
            },
          ]
        : [],
    })

    toast.success("Factura agregada")
    setCreateOpen(false)
    setSelectedInvoiceId(id)
    setForm({
      clientId: clients[0]?.id ?? "",
      amount: "",
      issueDate: new Date().toISOString().slice(0, 10),
      dueDate: "",
      description: "",
      owner: "Revenue Ops",
      priority: "medium",
    })
  }

  const handleSendReminder = (invoiceId: string, clientName: string) => {
    toast.success(`Recordatorio enviado a ${clientName}`, {
      description: `El workflow esta simulado para ${invoiceId}.`,
    })
  }

  const handleMarkPaid = (invoiceId: string) => {
    markInvoicePaid(invoiceId)
    toast.success("Factura marcada como cobrada")
  }

  const handleActionClick = (invoice: typeof invoices[0], e: React.MouseEvent) => {
    e.stopPropagation()
    const bucket = getInvoiceBucket(invoice)
    const isPaid = invoice.status === "paid"

    if (isPaid) {
      setSelectedInvoiceId(invoice.id)
    } else if (bucket === "overdue") {
      handleMarkPaid(invoice.id)
    } else if (bucket === "due-soon") {
      handleSendReminder(invoice.id, invoice.client)
    } else {
      setSelectedInvoiceId(invoice.id)
    }
  }

  return (
    <>
      <div className="mx-auto flex max-w-7xl flex-col gap-6 p-6">
        {/* Header */}
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-foreground">Facturas</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              Gestion de cobranzas y facturacion.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Button variant="outline" onClick={exportCSV}>
              <Download className="size-4" />
              Exportar CSV
            </Button>
            <Button onClick={() => setCreateOpen(true)}>
              <FilePlus2 className="size-4" />
              Nueva factura
            </Button>
          </div>
        </div>

        {/* Collections Alert - More prominent with client chips */}
        {(focusCollections || invoiceSummary.overdueCount > 0) && overdueClients.length > 0 && (
          <div className="flex flex-col gap-3 rounded-lg border border-danger/30 bg-danger/5 px-4 py-3 lg:flex-row lg:items-center lg:justify-between">
            <div className="flex items-start gap-3">
              <AlertTriangle className="mt-0.5 size-5 shrink-0 text-danger" />
              <div className="flex flex-col gap-2">
                <p className="text-sm font-semibold text-danger">
                  {invoiceSummary.overdueCount} factura{invoiceSummary.overdueCount !== 1 ? "s" : ""} vencida{invoiceSummary.overdueCount !== 1 ? "s" : ""} por {formatCurrency(invoiceSummary.overdueAmount)}
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {overdueClients.map((clientName) => (
                    <Badge
                      key={clientName}
                      variant="outline"
                      className="border-danger/30 bg-danger/10 text-danger"
                    >
                      {clientName}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
            <Button
              size="sm"
              onClick={() => router.push("/cashflow?focus=zero-day")}
            >
              Ver impacto en caja
            </Button>
          </div>
        )}

        {/* Summary Cards - Keep exactly as they are */}
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {summaryCards.map((card) => {
            const Icon = card.icon
            return (
              <button
                key={card.label}
                onClick={() => router.push(card.href)}
                className="text-left"
              >
                <Card className="h-full transition-all hover:border-primary/40 hover:bg-muted/20">
                  <CardContent className="flex h-full flex-col gap-4 px-5 py-5">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">
                        {card.label}
                      </span>
                      <div className="rounded-lg bg-muted p-2">
                        <Icon className="size-4 text-muted-foreground" />
                      </div>
                    </div>
                    <div>
                      <p className={cn("text-2xl font-bold tracking-tight", card.tone)}>{card.value}</p>
                      <p className="mt-1 text-xs text-muted-foreground">{card.detail}</p>
                    </div>
                  </CardContent>
                </Card>
              </button>
            )
          })}
        </div>

        {/* Invoice Table Card */}
        <Card>
          <CardHeader className="space-y-4">
            <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
              <div>
                <CardTitle>Lista de facturas</CardTitle>
                <CardDescription>
                  Filtra por estado, cliente o busca por termino.
                </CardDescription>
              </div>
            </div>

            {/* Simplified Filter Bar */}
            <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
              {/* Quick Filter Chips */}
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={() => setQuickFilter("all")}
                  className={cn(
                    "rounded-full px-3 py-1.5 text-sm font-medium transition-colors",
                    quickFilter === "all"
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted text-muted-foreground hover:bg-muted/80"
                  )}
                >
                  Todas
                </button>
                <button
                  onClick={() => setQuickFilter("overdue")}
                  className={cn(
                    "rounded-full px-3 py-1.5 text-sm font-medium transition-colors",
                    quickFilter === "overdue"
                      ? "bg-danger text-danger-foreground"
                      : "bg-muted text-muted-foreground hover:bg-muted/80"
                  )}
                >
                  Vencidas ({filterCounts.overdue})
                </button>
                <button
                  onClick={() => setQuickFilter("due-soon")}
                  className={cn(
                    "rounded-full px-3 py-1.5 text-sm font-medium transition-colors",
                    quickFilter === "due-soon"
                      ? "bg-warning text-warning-foreground"
                      : "bg-muted text-muted-foreground hover:bg-muted/80"
                  )}
                >
                  Proximas ({filterCounts.dueSoon})
                </button>
                <button
                  onClick={() => setQuickFilter("paid")}
                  className={cn(
                    "rounded-full px-3 py-1.5 text-sm font-medium transition-colors",
                    quickFilter === "paid"
                      ? "bg-success text-success-foreground"
                      : "bg-muted text-muted-foreground hover:bg-muted/80"
                  )}
                >
                  Cobradas
                </button>
              </div>

              {/* Search + Filters Popover */}
              <div className="flex w-full flex-col gap-2 lg:w-auto lg:flex-row">
                <div className="relative min-w-[240px]">
                  <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    value={search}
                    onChange={(event) => setSearch(event.target.value)}
                    className="pl-9"
                    placeholder="Buscar cliente o factura..."
                  />
                </div>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="gap-2">
                      <Filter className="size-4" />
                      Filtros
                      {clientFilter !== "all" && (
                        <Badge variant="secondary" className="ml-1">1</Badge>
                      )}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-72" align="end">
                    <div className="grid gap-4">
                      <div className="space-y-2">
                        <h4 className="font-medium leading-none">Cliente</h4>
                        <Select value={clientFilter} onValueChange={setClientFilter}>
                          <SelectTrigger>
                            <SelectValue placeholder="Todos los clientes" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">Todos los clientes</SelectItem>
                            {clientRecords.map((client) => (
                              <SelectItem key={client.id} value={client.id}>
                                {client.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      {clientFilter !== "all" && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setClientFilter("all")}
                          className="w-full"
                        >
                          Limpiar filtros
                        </Button>
                      )}
                    </div>
                  </PopoverContent>
                </Popover>
              </div>
            </div>
          </CardHeader>

          <CardContent className="px-6 pb-6">
            {/* 5-Column Table: Cliente | Monto | Vence | Estado | Accion */}
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Cliente</TableHead>
                  <TableHead>Monto</TableHead>
                  <TableHead>Vence</TableHead>
                  <TableHead>Estado</TableHead>
                  <TableHead className="text-right">Accion</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredInvoices.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="h-24 text-center">
                      <div className="flex flex-col items-center gap-2">
                        <CheckCircle2 className="size-8 text-success" />
                        <p className="text-sm text-muted-foreground">Todo en orden. No hay facturas que coincidan.</p>
                      </div>
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredInvoices.map((invoice) => {
                    const bucket = getInvoiceBucket(invoice)
                    const isPaid = invoice.status === "paid"
                    const highlighted = searchParams.get("highlight") === invoice.id
                    const actionConfig = getActionButton(bucket, isPaid)

                    return (
                      <TableRow
                        key={invoice.id}
                        onClick={() => setSelectedInvoiceId(invoice.id)}
                        className={cn(
                          "cursor-pointer",
                          getRowBorderClass(bucket),
                          highlighted && "bg-primary/10 ring-1 ring-primary/30",
                        )}
                      >
                        <TableCell>
                          <div>
                            <p className="font-medium text-foreground">{invoice.client}</p>
                            <p className="text-xs text-muted-foreground">{invoice.id}</p>
                          </div>
                        </TableCell>
                        <TableCell className="font-semibold">{formatCurrency(invoice.amount)}</TableCell>
                        <TableCell>
                          <span className="text-sm">{formatShortDate(invoice.dueDate)}</span>
                        </TableCell>
                        <TableCell>
                          <Badge className={toneForBucket(bucket)}>
                            {bucket === "overdue" ? "Vencida" :
                             bucket === "due-soon" ? "Por vencer" :
                             bucket === "paid" ? "Cobrada" : "Pendiente"}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant={actionConfig.variant}
                            size="sm"
                            onClick={(e) => handleActionClick(invoice, e)}
                          >
                            {actionConfig.label}
                            {actionConfig.variant === "ghost" && <ChevronRight className="size-4" />}
                          </Button>
                        </TableCell>
                      </TableRow>
                    )
                  })
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      {/* Detail Sheet - Action buttons FIRST */}
      <Sheet open={Boolean(selectedInvoice)} onOpenChange={(open) => !open && setSelectedInvoiceId(null)}>
        <SheetContent className="flex w-full flex-col overflow-y-auto sm:max-w-xl">
          {selectedInvoice && (
            <>
              {/* Header */}
              <SheetHeader className="border-b pb-4">
                <div className="flex items-center gap-2">
                  <Badge className={toneForBucket(getInvoiceBucket(selectedInvoice))}>
                    {getInvoiceBucket(selectedInvoice) === "overdue" ? "Vencida" :
                     getInvoiceBucket(selectedInvoice) === "due-soon" ? "Por vencer" :
                     getInvoiceBucket(selectedInvoice) === "paid" ? "Cobrada" : "Pendiente"}
                  </Badge>
                  <Badge className="bg-muted text-muted-foreground hover:bg-muted">
                    {selectedInvoice.priority === "high" ? "Alta" :
                     selectedInvoice.priority === "low" ? "Baja" : "Media"} prioridad
                  </Badge>
                </div>
                <SheetTitle className="mt-3 text-xl">{selectedInvoice.id}</SheetTitle>
                <SheetDescription>
                  {selectedInvoice.client} - {selectedInvoice.owner}
                </SheetDescription>
              </SheetHeader>

              {/* ACTION BUTTONS ROW - Immediately after header */}
              <div className="flex flex-wrap gap-2 border-b py-4">
                {selectedInvoice.status !== "paid" && (
                  <Button onClick={() => handleMarkPaid(selectedInvoice.id)}>
                    <CheckCircle2 className="size-4" />
                    Marcar cobrada
                  </Button>
                )}
                <Button
                  variant="outline"
                  onClick={() => handleSendReminder(selectedInvoice.id, selectedInvoice.client)}
                >
                  <Mail className="size-4" />
                  Enviar recordatorio
                </Button>
                <Button
                  variant="ghost"
                  onClick={() => {
                    router.push(buildHref({ pathname: "/clients", params: { highlight: selectedInvoice.clientId } }))
                    setSelectedInvoiceId(null)
                  }}
                >
                  <User className="size-4" />
                  Ver cliente
                </Button>
              </div>

              {/* Amount + Dates + Description */}
              <div className="flex-1 space-y-6 py-4">
                <Card>
                  <CardContent className="grid gap-4 px-5 py-5 sm:grid-cols-2">
                    <div>
                      <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground">Monto</p>
                      <p className="mt-2 text-2xl font-bold text-foreground">
                        {formatCurrency(selectedInvoice.amount)}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground">Impacto en runway</p>
                      <p className="mt-2 text-lg font-semibold text-success">
                        +{Math.max(1, Math.round(selectedInvoice.amount / Math.max(burnRate, 1)))} dias
                      </p>
                    </div>
                    <div className="rounded-xl border border-border/80 bg-muted/10 p-4">
                      <p className="text-xs text-muted-foreground">Fecha de emision</p>
                      <p className="mt-1 font-medium text-foreground">{formatShortDate(selectedInvoice.issueDate)}</p>
                    </div>
                    <div className="rounded-xl border border-border/80 bg-muted/10 p-4">
                      <p className="text-xs text-muted-foreground">Vencimiento</p>
                      <p className="mt-1 font-medium text-foreground">{formatShortDate(selectedInvoice.dueDate)}</p>
                    </div>
                  </CardContent>
                </Card>

                {/* Description */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Descripcion</CardTitle>
                  </CardHeader>
                  <CardContent className="px-6 pb-6">
                    <p className="text-sm text-muted-foreground">{selectedInvoice.description}</p>
                  </CardContent>
                </Card>

                {/* Payment History */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Historial de pagos</CardTitle>
                    <CardDescription>
                      Pagos realizados y esperados para esta factura.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3 px-6 pb-6">
                    {selectedInvoice.paymentHistory.length === 0 && selectedInvoice.expectedPayments.length === 0 ? (
                      <p className="text-sm text-muted-foreground">Sin eventos de pago registrados.</p>
                    ) : (
                      <>
                        {selectedInvoice.paymentHistory.map((payment) => (
                          <div
                            key={`${payment.date}-${payment.note}`}
                            className="rounded-xl border border-success/20 bg-success/5 p-4"
                          >
                            <div className="flex items-center justify-between gap-3">
                              <div>
                                <p className="text-sm font-medium text-foreground">{payment.note}</p>
                                <p className="text-xs text-muted-foreground">{formatShortDate(payment.date)}</p>
                              </div>
                              <p className="text-sm font-semibold text-success">
                                {formatSignedCurrency(payment.amount)}
                              </p>
                            </div>
                          </div>
                        ))}
                        {selectedInvoice.expectedPayments.map((payment) => (
                          <div
                            key={`${payment.date}-${payment.note}`}
                            className="rounded-xl border border-primary/20 bg-primary/5 p-4"
                          >
                            <div className="flex items-center justify-between gap-3">
                              <div>
                                <p className="text-sm font-medium text-foreground">{payment.note}</p>
                                <p className="text-xs text-muted-foreground">{formatShortDate(payment.date)}</p>
                              </div>
                              <p className="text-sm font-semibold text-primary">
                                {formatSignedCurrency(payment.amount)}
                              </p>
                            </div>
                          </div>
                        ))}
                      </>
                    )}
                  </CardContent>
                </Card>
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>

      {/* Create Invoice Dialog */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Crear factura</DialogTitle>
            <DialogDescription>
              Agrega una nueva factura al sistema para gestionar su cobranza.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-2">
            <div className="grid gap-2">
              <label className="text-sm font-medium text-foreground">Cliente</label>
              <Select
                value={form.clientId}
                onValueChange={(value) => setForm((current) => ({ ...current, clientId: value }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecciona un cliente" />
                </SelectTrigger>
                <SelectContent>
                  {clients.map((client) => (
                    <SelectItem key={client.id} value={client.id}>
                      {client.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="grid gap-2">
                <label className="text-sm font-medium text-foreground">Monto</label>
                <Input
                  type="number"
                  value={form.amount}
                  onChange={(event) => setForm((current) => ({ ...current, amount: event.target.value }))}
                  placeholder="9800"
                />
              </div>
              <div className="grid gap-2">
                <label className="text-sm font-medium text-foreground">Responsable</label>
                <Input
                  value={form.owner}
                  onChange={(event) => setForm((current) => ({ ...current, owner: event.target.value }))}
                  placeholder="Revenue Ops"
                />
              </div>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="grid gap-2">
                <label className="text-sm font-medium text-foreground">Fecha de emision</label>
                <Input
                  type="date"
                  value={form.issueDate}
                  onChange={(event) => setForm((current) => ({ ...current, issueDate: event.target.value }))}
                />
              </div>
              <div className="grid gap-2">
                <label className="text-sm font-medium text-foreground">Vencimiento</label>
                <Input
                  type="date"
                  value={form.dueDate}
                  onChange={(event) => setForm((current) => ({ ...current, dueDate: event.target.value }))}
                />
              </div>
            </div>

            <div className="grid gap-2">
              <label className="text-sm font-medium text-foreground">Prioridad</label>
              <Select
                value={form.priority}
                onValueChange={(value) =>
                  setForm((current) => ({ ...current, priority: value as "high" | "medium" | "low" }))
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="high">Alta</SelectItem>
                  <SelectItem value="medium">Media</SelectItem>
                  <SelectItem value="low">Baja</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-2">
              <label className="text-sm font-medium text-foreground">Descripcion</label>
              <Textarea
                value={form.description}
                onChange={(event) => setForm((current) => ({ ...current, description: event.target.value }))}
                placeholder="Describe el trabajo y por que importa esta factura."
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateOpen(false)}>
              Cancelar
            </Button>
            <Button
              onClick={handleCreateInvoice}
              disabled={!form.clientId || !form.amount || !form.issueDate || !form.dueDate || !form.description}
            >
              Crear factura
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}
